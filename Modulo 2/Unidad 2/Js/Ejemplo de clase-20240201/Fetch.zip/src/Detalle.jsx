function Detalle() {
  return (
    <div>
      <p>nombre: Moto g</p>
      <p>precio: $1000</p>
    </div>
  );
}

export default Detalle;
