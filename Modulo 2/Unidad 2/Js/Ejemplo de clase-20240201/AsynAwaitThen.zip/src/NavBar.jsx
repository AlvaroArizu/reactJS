function NavBar() {
  return (
    <div>
      <ul>
        <li>Inicio</li>
        <li>Productos</li>
      </ul>
    </div>
  );
}

export default NavBar;
