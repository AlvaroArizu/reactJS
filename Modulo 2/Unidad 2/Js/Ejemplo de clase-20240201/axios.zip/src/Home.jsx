import Productos from "./Productos.jsx";

function Home() {
  return (
    <div>
      Componente Home <Productos />
    </div>
  );
}

export default Home;
