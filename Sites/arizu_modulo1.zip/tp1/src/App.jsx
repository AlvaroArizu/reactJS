import Registro from './Registro';
import './App.css'

function App(){
  return(
    <div>
       <Registro />

    </div>
  );
}

export default App
