# Trabajo Practico 1

### Desarrollar el registro de una pagina web, en el registro tener los siguientes campos:

- Nombre
- Apellido
- Email
- Telefono
- Password
- Confirmar password

Realizar solo el maquetado utilizando react js y JSX, no se deben guardar los usuarios ni realizar lógica de validación de los mismos.
