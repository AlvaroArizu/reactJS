import React from "react";
import Productos from "../Components/Productos";

function Home() {
  return (
    <div>
      <h2>Productos Destacados</h2>
      <Productos />
    </div>
  );
}

export default Home;

